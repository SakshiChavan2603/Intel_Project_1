import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
from cryptography.fernet import Fernet

# Generate a key and instantiate a Fernet instance
def generate_key():
    return Fernet.generate_key()

# Encrypt a password
def encrypt_password(key, password):
    fernet = Fernet(key)
    encrypted_password = fernet.encrypt(password.encode())
    return encrypted_password

# Decrypt an encrypted password
def decrypt_password(key, encrypted_password):
    fernet = Fernet(key)
    decrypted_password = fernet.decrypt(encrypted_password).decode()
    return decrypted_password

# Save the key to a file
def save_key(key, filename):
    with open(filename, 'wb') as key_file:
        key_file.write(key)

# Load the key from a file
def load_key(filename):
    with open(filename, 'rb') as key_file:
        return key_file.read()

# Save the encrypted password to a file
def save_encrypted_password(encrypted_password, filename):
    with open(filename, 'wb') as password_file:
        password_file.write(encrypted_password)

# Load the encrypted password from a file
def load_encrypted_password(filename):
    with open(filename, 'rb') as password_file:
        return password_file.read()

# GUI application
class PasswordManager(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Password Manager")
        self.geometry("500x400")  # Correct the geometry method

        # Load and set the background image
        self.bg_image = Image.open("background1.jpg")
        self.bg_image = self.bg_image.resize((500, 400), Image.LANCZOS)  # Resize the image to match canvas size
        self.bg_photo = ImageTk.PhotoImage(self.bg_image)
        self.canvas = tk.Canvas(self, width=500, height=400)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.create_image(0, 0, image=self.bg_photo, anchor="nw")

        # GUI components
        self.password_label = tk.Label(self, text="Password:", bg="lightblue")
        self.password_entry = tk.Entry(self, show="*")
        self.encrypt_button = tk.Button(self, text="Encrypt", command=self.encrypt)
        self.encrypted_password_label = tk.Label(self, text="Encrypted Password:", bg="lightblue")
        self.encrypted_password_text = tk.Text(self, height=2, width=50)
        self.decrypt_button = tk.Button(self, text="Decrypt", command=self.decrypt)
        self.decrypted_password_label = tk.Label(self, text="Decrypted Password:", bg="lightblue")
        self.decrypted_password_text = tk.Text(self, height=2, width=50)

        # Place components on the canvas
        self.canvas.create_window(250, 50, window=self.password_label)
        self.canvas.create_window(250, 80, window=self.password_entry)
        self.canvas.create_window(250, 120, window=self.encrypt_button)
        self.canvas.create_window(250, 160, window=self.encrypted_password_label)
        self.canvas.create_window(250, 190, window=self.encrypted_password_text)
        self.canvas.create_window(250, 230, window=self.decrypt_button)
        self.canvas.create_window(250, 270, window=self.decrypted_password_label)
        self.canvas.create_window(250, 300, window=self.decrypted_password_text)

        self.key = generate_key()
        save_key(self.key, "secret.key")

    def encrypt(self):
        password = self.password_entry.get()
        if not password:
            messagebox.showerror("Error", "Please enter a password to encrypt.")
            return

        encrypted_password = encrypt_password(self.key, password)
        save_encrypted_password(encrypted_password, "encrypted_password.bin")
        self.encrypted_password_text.delete(1.0, tk.END)
        self.encrypted_password_text.insert(tk.END, encrypted_password.decode())

    def decrypt(self):
        try:
            encrypted_password = load_encrypted_password("encrypted_password.bin")
            decrypted_password = decrypt_password(self.key, encrypted_password)
            self.decrypted_password_text.delete(1.0, tk.END)
            self.decrypted_password_text.insert(tk.END, decrypted_password)
        except Exception as e:
            messagebox.showerror("Error", f"Decryption failed: {e}")

if __name__ == "__main__":
    app = PasswordManager()
    app.mainloop()